<?php

$xpdo_meta_map = array (
  'comSimpleObject' => 
  array (
    0 => 'NotifyStockMessage',
    1 => 'NotifyStockRequest',
  ),
);
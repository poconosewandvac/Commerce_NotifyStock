NotifyStock for Commerce
------------------------

Allow customers to receive a notification when a product is back in stock.
